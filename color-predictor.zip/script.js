function digitSum(n) {
  return n.toString().split('').reduce((a, b) => a + Number(b), 0);
}

function getColorByDigit(digit) {
  const colors = {
    0: 'Red Violet',
    1: 'Green',
    2: 'Red',
    3: 'Green',
    4: 'Red',
    5: 'Green Violet',
    6: 'Red',
    7: 'Green',
    8: 'Red',
    9: 'Green'
  };
  return colors[digit] || 'Unknown';
}

function predictColor() {
  const input = document.getElementById('numbers').value;
  const nums = input.split(',').map(x => parseInt(x.trim())).filter(n => !isNaN(n));

  if (nums.length === 0) {
    document.getElementById('output').innerText = 'Please enter valid numbers.';
    return;
  }

  const total = nums.reduce((a, b) => a + b, 0);
  const sumDigit = digitSum(total);
  const finalDigit = digitSum(sumDigit);
  const color = getColorByDigit(finalDigit);

  document.getElementById('output').innerHTML = `
    Total: ${total} <br>
    Digit Sum: ${sumDigit} → ${finalDigit} <br>
    🎯 Predicted Color: <b style="color: yellow">${color}</b>
  `;
}