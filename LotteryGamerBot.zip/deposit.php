<?php
$conn = new mysqli("localhost", "root", "", "lottery_db");

$amount = $_POST['amount'];
$trx_id = $_POST['trx_id'];
$user_id = 1;

$sql = "INSERT INTO deposit_requests (user_id, amount, trx_id, status) VALUES ($user_id, $amount, '$trx_id', 'pending')";
$conn->query($sql);

echo "✅ Deposit request sent!";
?>
