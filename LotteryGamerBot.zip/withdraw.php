<?php
$conn = new mysqli("localhost", "root", "", "lottery_db");

$amount = $_POST['amount'];
$number = $_POST['number'];
$user_id = 1;

$sql = "INSERT INTO withdraw_requests (user_id, amount, number, status) VALUES ($user_id, $amount, '$number', 'pending')";
$conn->query($sql);

echo "✅ Withdraw request sent!";
?>
