CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(100),
  balance FLOAT DEFAULT 0
);

CREATE TABLE deposit_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  amount FLOAT,
  trx_id VARCHAR(50),
  status VARCHAR(20)
);

CREATE TABLE withdraw_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  amount FLOAT,
  number VARCHAR(20),
  status VARCHAR(20)
);
